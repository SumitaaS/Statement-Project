package com.sbi.statement.layer4;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

import com.itextpdf.text.DocumentException;

@Service
public interface MailService {

	public void sendMail(String info, String email, String generatePdfPath,LocalDate fromDate, LocalDate toDate)throws DocumentException ;
}
