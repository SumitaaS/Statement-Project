package com.sbi.statement.layer2;

public final class Constants {

    private Constants() {
            // restrict instantiation
    }

//    public static final double PI = 3.14159;
//    public static final double PLANCK_CONSTANT = 6.62606896e-34;
//    
    public static final String EMAIL_TEMPLATE = "<div class=\"container\">\r\n"
    		+ "  <div class=\"template-banner\">\r\n"
    		+ "    <img src='https://static.wixstatic.com/media/8e5840_ada253104dc14a75b14afa0e23349d60~mv2.png/v1/fit/w_570%2Ch_196%2Cal_c/file.png' alt=\"SBI mail banner\" />\r\n"
    		+ "  </div>\r\n"
    		+ "  \r\n"
    		+ "  <div class=\"email-body\">\r\n"
    		+ "    <p>\r\n"
    		+ "      Dear Customer,\r\n"
    		+ "      <br><br>\r\n"
    		+ "      Your account e-statement is available at your fingertips. You can view them online whenever required. Please find the account e-statement for your perusal.\r\n"
    		+ "      <br>\r\n"
    		+ "      Your e-statement  is protected by a password, which is your account password registered with Bank\r\n"
    		+ "      <br>\r\n"
    		+ "      In case of any issues, please lodge a complaint online at <i><ins>contactcenter@sbi.co.in</ins></i> or by calling our <ins>1800 425 3800</ins> toll free numbers or by contacting your home branch.\r\n"
    		+ "      <br><br>\r\n"
    		+ "      With Best Regards,\r\n"
    		+ "      <br>\r\n"
    		+ "      Team SBI\r\n"
    		+ "      \r\n"
    		+ "      <br><br>\r\n"
    		+ "      ** Please note: You will need Adobe Acrobat to open the attachment. Please donot reply to this email as it is a computer generated email.\r\n"
    		+ "    </p>\r\n"
    		+ "  </div>\r\n"
    		+ "</div>";
}

